
void				Init_ADC(void) ;	
unsigned int		Get_VR1(void) ;
unsigned int		Get_VR2(void) ;
unsigned int		Get_AD_Key(void) ;
