
#include 	<p30F4011.h>
#include	<spi.h>
#include 	"spiSubs.h"


#define		MODE_SPICS	ADPCFGbits.PCFG2


void	Init_SPI(void)
{
	unsigned int 	config1 , config2 ;

	MODE_SPI_CS = 1 ;								//  CS PIN for SPIis Digital Mode
	SPI_CS = 1 ;									//	Inactive CS
	DIR_SPI_CS = 1 ;								//	SS PIN is "input" when Slave mode 
	
	SPI1CON = 0x22dc ;								//	0010 0010 1101 1100
	SPI1STAT = 0xa000 ;								//	1010 0000 0000 0000
	SPI1BUF = 0x00 ;
	
	ConfigIntSPI1(SPI_INT_EN & SPI_INT_PRI_4) ;

}

