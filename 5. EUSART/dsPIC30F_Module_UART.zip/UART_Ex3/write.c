#include <stdio.h>
#include "simio.h"
#include "C30EVM_LCD.h"			// �NLCD�禡���쫬�ŧi�ɮקt�J

write(int handle, void *buffer, unsigned int len)
{
	int i;
	SIMIO simio;

	switch (handle)
	{
	case 0:
	case 1:
	case 2:

		for (i = len; i; --i)
		{
			putcLCD ( *(char*)buffer++);
		}
		break;

	default:
		break;
	}
	return(len);
}

